
import React, { useRef, useEffect, useContext } from "react"
import BadgerLoginStatusContext from "../contexts/BadgerLoginStatusContext";

export default function BadgerLogout() {

    const [loginStatus, setLoginStatus] = useContext(BadgerLoginStatusContext);
    const sessionLog = JSON.parse(sessionStorage.getItem("sessionLog"));

    useEffect(() => {
        fetch('https://cs571api.cs.wisc.edu/rest/f24/hw6/logout', {
            method: 'POST',
            headers: {
                "X-CS571-ID": CS571.getBadgerId(),
                "Content-Type": "application/json"
            },
            credentials: "include",
            body: JSON.stringify({
                username: sessionStorage.getItem("username"),
                pin: sessionStorage.getItem("password")
            })
        })  
        .then(res => { 
            //console.log(res.status);
            if(res.status === 200) {
                alert("You have been logged out.");
                setLoginStatus(false);
                sessionStorage.setItem("sessionLog",JSON.stringify(false));
            }
        })
    }, []);

    return <>
        <h1>Logout</h1>
        <p>You have been successfully logged out.</p>
    </>
}
