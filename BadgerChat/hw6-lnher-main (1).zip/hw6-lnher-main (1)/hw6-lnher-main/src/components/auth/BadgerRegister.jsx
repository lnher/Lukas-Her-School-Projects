import React, { useRef, useEffect, useState, useContext } from "react"
import { useNavigate } from "react-router-dom";
import { Button, Form } from "react-bootstrap";
import BadgerLoginStatusContext from "../contexts/BadgerLoginStatusContext";

export default function BadgerRegister() {

    const [loginStatus, setLoginStatus] = useContext(BadgerLoginStatusContext);
    const sessionLog = JSON.parse(sessionStorage.getItem("sessionLog"));
    const usernameRef = useRef();
    const passwordRef = useRef();
    const confirmRef = useRef();
    const navigate = useNavigate();

    //console.log("logged in: " + loginStatus);
    sessionLog ? console.log(sessionLog): console.log("no sessionLog");

    function handleLoginSubmit(e) {
        e?.preventDefault();

        //console.log(usernameRef.current.value, passwordRef.current.value, confirmRef.current.value);

        //checks
        if(usernameRef.current.value === "" || passwordRef.current.value === "") {
            alert("You must provide both a username and pin!")
        }
        else if(!(/^\d{7}$/.test(passwordRef.current.value))) {
            alert("Your pin must be a 7-digit number!")
        }
        else if(passwordRef.current.value !== confirmRef.current.value) {
            alert("Your pins do not match!");
        }
        else { 
            fetch("https://cs571api.cs.wisc.edu/rest/f24/hw6/register", {
                method: "POST",
                credentials: "include",
                headers: {
                    "X-CS571-ID": CS571.getBadgerId(),
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    username: usernameRef.current.value,
                    pin: passwordRef.current.value
                })
                
            })
            .then(res => {
                    if(res.status === 200) {
                        alert("Registration successful!");
                        setLoginStatus(true);
                        sessionStorage.setItem("sessionLog",JSON.stringify(true));
                        sessionStorage.setItem("username", JSON.stringify(usernameRef.current.value));
                        sessionStorage.setItem("password", JSON.stringify(passwordRef.current.value));
                        navigate("/");
                    }
                    else if(res.status === 409) {
                        alert("That username has already been taken!");
                    }
                    //console.log(res);
            })
        }
    }

    return <>
        <h1>Register</h1>
        <Form onSubmit={handleLoginSubmit}>
            <Form.Label htmlFor="usernameInput">Username</Form.Label>
            <Form.Control id="usernameInput" ref={usernameRef}></Form.Control>
            <Form.Label htmlFor="passwordInput">Pin</Form.Label>
            <Form.Control id="passwordInput" type="password" ref={passwordRef}></Form.Control>
            <Form.Label htmlFor="confirmInput">Confirm Pin</Form.Label>
            <Form.Control id="confirmInput" type="password" ref={confirmRef}></Form.Control>
            <br/>
            <Button type="submit" onClick={handleLoginSubmit}>Register</Button>
        </Form>
    </>
}
