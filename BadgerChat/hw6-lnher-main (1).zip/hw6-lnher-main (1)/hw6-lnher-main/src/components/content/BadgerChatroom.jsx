import React, { useEffect, useState, useRef, useContext } from "react"
import { Col, Container, Row, Pagination, Button, Form } from "react-bootstrap";
import BadgerMessage from "./BadgerMessage";
import BadgerLoginStatusContext from "../contexts/BadgerLoginStatusContext";

export default function BadgerChatroom(props) {

    const [messages, setMessages] = useState([]);
    const [page, setPage] = useState(1);
    let pageList = [1,2,3,4];
    const titleRef = useRef();
    const contentRef = useRef();
    const sessionLog = JSON.parse(sessionStorage.getItem("sessionLog"));
    const [loginStatus, setLoginStatus] = useContext(BadgerLoginStatusContext);

    if(!loginStatus || !sessionLog) {
        alert("You must be logged in to post!")
    }

    const loadMessages = () => {
        fetch(`https://cs571api.cs.wisc.edu/rest/f24/hw6/messages?chatroom=${props.name}&page=` + page, {
            headers: {
                "X-CS571-ID": CS571.getBadgerId()
            }
        }).then(res => res.json()).then(json => {
            setMessages(json.messages)
            //console.log(page);
        })
    };


    // Why can't we just say []?
    // The BadgerChatroom doesn't unload/reload when switching
    // chatrooms, only its props change! Try it yourself.
    useEffect(loadMessages, [props, page]);

    //console.log(pageList);
    //console.log(messages);

    function handleCommentSubmit(e) {
        e?.preventDefault();

        console.log(titleRef.current.value, contentRef.current.value);

        //checks
        if(titleRef.current.value === "" || contentRef.current.value === "") {
            alert("You must provide both a title and content")
        }
        else { 
            fetch("https://cs571api.cs.wisc.edu/rest/f24/hw6/messages?chatroom=" + props.name, {
                method: "POST",
                credentials: "include",
                headers: {
                    "X-CS571-ID": CS571.getBadgerId(),
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    title: titleRef.current.value,
                    content: contentRef.current.value
                })
                
            })
            .then(res => {
                    if(res.status === 200) {
                        alert("Post sucessful!");
                        loadMessages();
                    }
                    else if(res.status === 401) {
                        alert("You must be logged in to post!");
                    }
                    else if(res.status === 413) {
                        alert("Too much data!");
                    }
                    //console.log(res);
            })
        }
    }

    function deletePost(id) {
        console.log(id);

        fetch("https://cs571api.cs.wisc.edu/rest/f24/hw6/messages?id=" + id, {
            method: "DELETE",
            credentials: "include",
            headers: {
                "X-CS571-ID": CS571.getBadgerId(),
            },
        })
        .then(res => {
                if(res.status === 200) {
                    alert("Delete sucessful!");
                    loadMessages();
                }
                if(res.status === 401) {
                    alert("You must be logged in to do that!");
                }
                //console.log(res);
        })
    }

    return <>
        <h1>{props.name} Chatroom</h1>
        {
            /* TODO: Allow an authenticated user to create a post. */
        }
        <hr/>       
        <Container fluid>
            <Row>
                <Col xs={12} md={12} lg={12}>
                    <Form onSubmit={handleCommentSubmit}>
                    <Form.Label htmlFor="titleInput">Post Title</Form.Label>
                    <Form.Control id="titleInput" ref={titleRef}></Form.Control>
                    <Form.Label htmlFor="contentInput">Post Content</Form.Label>
                    <Form.Control id="contentInput" ref={contentRef}></Form.Control>
                    <br/>
                    <Button type="submit" onClick={handleCommentSubmit}>Create Post</Button>
                    </Form>
                </Col>
                <Col xs={12} md={12} lg={12} >
                {messages.length > 0 ?
                    <>
                        <Container fluid>
                            <Row> 
                                {
                                    messages.map((text) => 
                                        <Col key={text.id} xs={12} md={6} lg={4} xl={3}>
                                            <BadgerMessage deletePost={deletePost} loggedInAs={sessionStorage.getItem("username")} {...text}/>   
                                        </Col>
                                    )
                                }
                            </Row>
                        </Container>
                        <Container>
                            <Row>
                                <Pagination>
                                    {pageList.map(pg => <Pagination.Item key={pg} active={page===pageList[pg-1]} onClick={() => setPage(pg)}>{pg}</Pagination.Item>)}
                                </Pagination>
                            </Row>
                        </Container>
                    </>
                    :
                    <>
                        <p>There are no messages on this page yet!</p>
                    </>
                }
                </Col>
            </Row>
        </Container>
        
    </>
}
