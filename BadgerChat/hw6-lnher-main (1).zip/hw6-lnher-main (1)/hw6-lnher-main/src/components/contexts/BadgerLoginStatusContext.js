import { createContext } from "react";

const BadgerLoginStatusContext = createContext([]);

export default BadgerLoginStatusContext;