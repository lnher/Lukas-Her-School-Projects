#define _GNU_SOURCE

#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <stdarg.h>

#include <unistd.h>
#include <minispark.h>
#include <pthread.h>
#include <semaphore.h>

//List implementation
struct List {
  void **array; // an array that holds the data
  int size; // size of list
};

List* list_initalize(int numEntries) {
  List* returnMe = malloc(sizeof(List));
  returnMe->size = numEntries;
  returnMe->array = malloc(sizeof(void*) * numEntries);

  return returnMe;
}

//frees all items in the list
void list_free_me(List *list) {
  for(int i = 0; i < list->size; i++) {
    free(list->array[i]);
  }

  free(list);
}

// adds addMe to the end of the list
void list_append_element(List *list, void *addMe) {
  void **arr = list->array;
  void **tempArray;
  tempArray = realloc(arr, (sizeof(void*) * (list->size + 1)));
  tempArray[list->size] = addMe;

  // free old list and update it to have new list
  //free(arr);
  list->array = tempArray;
  list->size++;
}

// returns the value of what is at index
void* list_get_element(List* list, int index) {
  return list->array[index];
}


// ALL STRUCTS
struct TaskNode { // used to to make a linked list of tasks
    Task work; // keeps track of what this task is supposed to do
    struct TaskNode* next; // keeps track of the next task
};

// used to keep track of everything that needs to be done, implemented as a stack
struct WorkStack {
    struct TaskNode* head;
    int size;
    int numExecuting;
    pthread_mutex_t lock; // used to add and remove things from the queue
    sem_t semaphore; // not sure if I need this
};

// the main threadpool
struct Threadpool {
    int numWorkerThreads; // number of worker threads 
    pthread_t *workerArr;
};

struct MetricNode{
  TaskMetric* data;
  struct MetricNode* next;
};

struct MetricPool{
  FILE* fp; 
  pthread_mutex_t lock; // to add and remove stuff
  sem_t semaphore; // to wake up thread
  struct MetricNode* head;
  struct MetricNode* tail;
  int size;
  int numWorking;
  pthread_t metricworker;
};

// struct MetricWorker {
//   int numWorkerThreads; // number of worker threads 
//   pthread_t metricworker;
// };

// GLOBAL VARS
struct WorkStack* workstack;
struct Threadpool* threadpool;
struct MetricPool* metricpool;
//struct MetricWorker* metricworker;

// METRICPOOL FUNCTIONS

void print_formatted_metric(TaskMetric* metric, FILE* fp);

// returns the node it printed
struct MetricNode* metricpool_print() {
  // grab lock
  if(pthread_mutex_lock(&metricpool->lock) != 0) {
    perror("pthread_mutex_lock");
  }

  metricpool->numWorking++;

  struct MetricNode* temp = metricpool->head;

  print_formatted_metric(temp->data, metricpool->fp);

  metricpool->head = temp->next;
  metricpool->size--;

  metricpool->numWorking--;

  // release lock
  if(pthread_mutex_unlock(&metricpool->lock) != 0) {
    perror("pthread_mutex_unlock");
  }

  return temp;
}

void metricpool_submit(TaskMetric* addMe) {
  // grab lock
  if(pthread_mutex_lock(&metricpool->lock) != 0) {
    perror("pthread_mutex_lock");
  }

  struct MetricNode* toAdd = malloc(sizeof(struct MetricNode));
  toAdd->data = addMe;
  toAdd->next = NULL;

  if(metricpool->head == NULL && metricpool->size == 0) {
    metricpool->head = toAdd;
    metricpool->tail = toAdd;
    metricpool->size++;
  }
  else {
    metricpool->tail->next = toAdd;
    metricpool->tail = toAdd;
    metricpool->size++;
  }

  //post to semaphore that there is something in the queue to do
  if(sem_post(&metricpool->semaphore) != 0 ) {
    perror("sem_post");
  }

  // release lock
  if(pthread_mutex_unlock(&metricpool->lock) != 0) {
    perror("pthread_mutex_unlock");
  }
}

TaskMetric* create_metric(RDD* rdd, int pnum) {
  TaskMetric* returnMe = malloc(sizeof(TaskMetric));
  returnMe->rdd = rdd;
  returnMe->pnum = pnum;
  clock_gettime(CLOCK_MONOTONIC, &returnMe->created);

  return returnMe;
}

void metric_wait() {
  while(metricpool->head != NULL || metricpool->numWorking > 0) {

  }
}

void metric_destroy() {
  metric_wait();

  //send special destroy task
  TaskMetric* temp = create_metric(NULL, -99);

  metricpool_submit(temp);

  //wait for all threads to return
  if(pthread_join(metricpool->metricworker, NULL) != 0) {
    perror("pthread_join");
  }
}

// for the metric thread
void metric_thread_function(void * stuff) {
  while(1) {
    // grab semaphore
    if(sem_wait(&metricpool->semaphore) != 0) {
      perror("sem_wait");
      return;
    }

    TaskMetric *temp = metricpool->head->data;

    // if it is the special destory node then exit
    if(temp->pnum == -99) {
      metricpool->head = NULL;
      return;
    }
    else{
      metricpool_print();
    }
  }
  stuff = stuff; // so it doesn't yell at me
}

//
void metricpool_init() {
  struct MetricPool* returnMe = malloc(sizeof(struct MetricPool));
  returnMe->fp = fopen("metrics.log", "w");

  if(returnMe->fp == NULL) {
    perror("fopen");
  }

  // create lock
  if(pthread_mutex_init(&returnMe->lock, NULL) != 0) {
    perror("pthread_mutex_init");
  }

  // create a semaphore 
  if(sem_init(&returnMe->semaphore, 1, 0) != 0) {
    perror("sem_init");
  }

  returnMe->head = NULL;
  returnMe->tail = NULL;
  returnMe->size = 0;

  metricpool = returnMe;

  // TESTING

  void* fn = metric_thread_function;

  //returnMe->metricworker = malloc(sizeof(pthread_t));
  if(pthread_create(&returnMe->metricworker, NULL, fn, NULL) != 0) {
    perror("pthread_create"); // only if one of the pthreads fail
  }

  char* name = "metric worker";

  if(pthread_setname_np(returnMe->metricworker, name) != 0) {
    perror("pthread_setname_np");
  }

  // TESTING

  metricpool = returnMe;
}

// void metricworker_init() {
//   struct MetricWorker* temp = malloc(sizeof(struct MetricWorker));
//   temp->numWorkerThreads = 1;
//   temp->metricworker = malloc(sizeof(pthread_t) * 1);

//   void* fn = metric_thread_function;

  

//   metricworker = temp;
// }

// WORKSTACK FUNCTIONS
void work_stack_init() { // creates an empty WorkStack, UNTESTED
    struct WorkStack *returnMe = malloc(sizeof(struct WorkStack));
    returnMe->head = NULL;
    returnMe->size = 0;
    returnMe->numExecuting = 0;

    // initialize the lock
    if(pthread_mutex_init(&returnMe->lock, NULL) != 0) {
        perror("pthread_mutex_init");
    }

    // create a semaphore that can be shared between processess and 
    if(sem_init(&returnMe->semaphore, 1, 0) != 0) {
        perror("sem_init");
    }

    workstack = returnMe;
}

// removes the top of the stack and returns it's task,
// if there is nothing then returns null, DONE-ISH UNTESTED
Task *work_stack_pop() {
  struct TaskNode *node;

  //get lock
  if(pthread_mutex_lock(&workstack->lock) != 0) {
    perror("pthread_mutex_lock");
  }

  // if there is nothing in the stack wait a bit
  // while(workstack->size == 0 || workstack->head == NULL) {
  // }
  // while(workstack->size == 0 || workstack->head == NULL) {
  //   printf("nothing to do");
  // }
    
  node = workstack->head;
  workstack->head = node->next;
  workstack->size--;

  //release lock
  if(pthread_mutex_unlock(&workstack->lock) != 0) {
    perror("pthread_mutex_unlock");
  }

  return &node->work;
}

// adds a task to the top of the WorkStack, UNTESTED
void work_stack_submit(Task *task) {
    struct TaskNode* node = malloc(sizeof(struct TaskNode));
    node->work = *task;
    node->next = NULL;

    //get lock
    if(pthread_mutex_lock(&workstack->lock) != 0) {
        perror("pthread_mutex_lock");
    }

    if(workstack->head == NULL || workstack->size == 0) {
      workstack->head = node;
    }
    else {
        node->next = workstack->head;
        workstack->head = node;
    }

    workstack->size++;

    //release lock
    if(pthread_mutex_unlock(&workstack->lock) != 0) {
        perror("pthread_mutex_unlock");
    }

    //post to semaphore that there is something in the queue to do
    if(sem_post(&workstack->semaphore) != 0 ) {
      perror("sem_post");
  }
}

// used to make a new task
Task* create_task(RDD* rdd, int pnum) {
    Task* returnMe = malloc(sizeof(Task));
    returnMe->rdd = rdd;
    returnMe->pnum = pnum;
    returnMe->metric = create_metric(rdd, pnum);

    return returnMe;
}

// THREADPOOL FUNCTIONS
//takes a task and does it
void do_task(Task *task) {
    int pnum = task->pnum;
    RDD *dependOne;
    //RDD *dependTwo;
    struct List *temp;
    struct List *myPart;
    struct List *dependPart;
    struct List *dependPartTwo;
    void *fn = task->rdd->fn; // the function pointer

    // do the task, TODO have to fix all logic
    // if is filebacked mapper(dep->partition[pnum])
    if(task->rdd->trans == FILE_BACKED) {
      // myPart = task->rdd->partitions;
      // fn = task->rdd->fn;
      // struct List* tempList;
      // void* element;
      // tempList = list_initalize(0);

      // while((element = ((Mapper)fn)(myPart->array[pnum])) != NULL) {
      //   list_append_element(tempList, element);
      // }

      // myPart->array[pnum] = tempList;
    }
    else if(task->rdd->trans == MAP) {
      // dep->partition[pnum] ??????
      // if it is nt filebacked
      // while (next(dep->partition[pnum] != null)) elm next() add (mapper(elm))
      // if is filebacked mapper(dep->partition[pnum])
      dependOne = task->rdd->dependencies[0];
      dependPart = dependOne->partitions;
      myPart = task->rdd->partitions;

      if(dependOne->trans == FILE_BACKED) {
        void* element;
        temp = list_initalize(0);

        while((element = ((Mapper)fn)(dependPart->array[pnum])) != NULL) {
          list_append_element(temp, element);
        }

        myPart->array[pnum] = temp;
      }
      else{
        myPart = (List*)task->rdd->partitions;
        dependPart = (List*)task->rdd->dependencies[0]->partitions->array[pnum];
        temp = list_initalize(dependPart->size);

        for(int i = 0; i < dependPart->size; i++) {
          temp->array[i] = ((Mapper)fn)(dependPart->array[i]);
        }

        myPart->array[pnum] = temp;
      }
    }
    else if(task->rdd->trans == FILTER) {
      myPart = (List*)task->rdd->partitions;
      dependPart = (List*)task->rdd->dependencies[0]->partitions->array[pnum];

      temp = list_initalize(0);

      for(int i = 0; i < dependPart->size; i++) {
        if(((Filter)fn)(dependPart->array[i], task->rdd->ctx)) {
          list_append_element(temp,dependPart->array[i]);
          myPart->array[pnum] = temp;
        }
        
        //myPart->array[i] = ((Mapper)fn)(dependPart->array[i]);
      }

      myPart->array[pnum] = temp;
      //temp = NULL; // for debug
    }
    else if(task->rdd->trans == JOIN) {
      myPart = (List*)task->rdd->partitions;
      dependPart = (List*)task->rdd->dependencies[0]->partitions->array[pnum];
      dependPartTwo = (List*)task->rdd->dependencies[1]->partitions->array[pnum];
      void* element;

      temp = list_initalize(0);
      myPart->array[pnum] = temp;

      for(int i = 0; i < dependPart->size; i++) {
        for(int j = 0; j< dependPartTwo->size; j++) {
          if((element = ((Joiner)fn)(dependPart->array[i], dependPartTwo->array[j], task->rdd->ctx)) != NULL) {
            list_append_element(temp, element);
            //myPart->array[pnum] = temp;
          }
        }
        //myPart->array[i] = ((Mapper)fn)(dependPart->array[i]);
      }

      myPart->array[pnum] = temp;
      //temp = NULL; // for debug     
    }
    else if(task->rdd->trans == PARTITIONBY) {
      myPart = (List*)task->rdd->partitions;
      dependPart = task->rdd->dependencies[0]->partitions;
      List* currPart;

      temp = list_initalize(0);

      for(int i = 0; i < dependPart->size; i++) {
        currPart = (List*)dependPart->array[i];
        for(int j = 0; j < currPart->size; j++) {
          // if partitions maps it the the pnum we're working on add it to the temp
          if(((Partitioner)fn)(currPart->array[j], task->rdd->numpartitions, task->rdd->ctx) == (long unsigned)pnum) {
            list_append_element(temp, currPart->array[j]);
            myPart->array[pnum] = temp; // assign it to the correct pnum
          }
        }
        
        //myPart->array[i] = ((Mapper)fn)(dependPart->array[i]);
      }

      myPart->array[pnum] = temp;
      //temp = NULL; // for debug
        // dependOne = task->rdd->dependencies[0];
        // myPart = task->rdd->partitions;
        // dependPart = dependOne->partitions;
        // fn = task->rdd->fn;

        // for(int j = 0; j < dependOne->numpartitions; j++) {
        //     for(int i = 0; i < myPart[pnum].size; i++) {
        //         if((int)((Partitioner)fn)(dependPart[pnum].array[i], task->rdd->numpartitions, task->rdd->ctx) == pnum) {
        //           //list_add_element(&myPart[pnum], dependPart[pnum].array[i]);
        //         }
        //     }
        // }
    }
}
// takes a task from the WorkStack and does it
// TODO need to do the task still, UNTESTED
void worker_thread_function(void* stuff) {
  // loop until special destory task is sent
  while(1) { 
    // grab semaphore and get the task
    if(sem_wait(&workstack->semaphore) != 0) {
      perror("sem_wait");
      return;
    }

    //get lock
    if(pthread_mutex_lock(&workstack->lock) != 0) {
      perror("pthread_mutex_lock");
    }
    workstack->numExecuting++;
    //get lock
    if(pthread_mutex_unlock(&workstack->lock) != 0) {
      perror("pthread_mutex_lock");
    }

    Task *task = work_stack_pop();

    if(task->pnum >= 0) { // check for valid pnum and if special destory task is given
      do_task(task); 

      // for metrics
      clock_gettime(CLOCK_MONOTONIC, &task->metric->scheduled);
      // calculate time it took
      task->metric->duration = TIME_DIFF_MICROS(task->metric->created, task->metric->scheduled);
      metricpool_submit(task->metric);
    }
    else { // only when given the special DESTORY task
      //get lock
      if(pthread_mutex_lock(&workstack->lock) != 0) {
        perror("pthread_mutex_lock");
      }
      workstack->numExecuting--;
      //get lock
      if(pthread_mutex_unlock(&workstack->lock) != 0) {
        perror("pthread_mutex_lock");
      }

      stuff = stuff; // so compiler doesn't yell at me
      return;
    }
    
    //get lock
    if(pthread_mutex_lock(&workstack->lock) != 0) {
      perror("pthread_mutex_lock");
    }
    workstack->numExecuting--;
    //get lock
    if(pthread_mutex_unlock(&workstack->lock) != 0) {
      perror("pthread_mutex_lock");
    }     
  }
}

// initialized the threadpool making workerthreads equal to numCores, UNTESTED
void thread_pool_init(int numCores) {
    struct Threadpool *returnMe = malloc(sizeof(struct Threadpool));
    returnMe->numWorkerThreads = numCores; // just checking
    returnMe->workerArr = malloc(sizeof(pthread_t) * returnMe->numWorkerThreads);

    void* fn = worker_thread_function;

    // create the correct pthreads and pass in workstack as an arg
    for(int i = 0; i < returnMe->numWorkerThreads; i++) {
        if(pthread_create(&returnMe->workerArr[i], NULL, fn, NULL) != 0) {
            perror("pthread_create"); // only if one of the pthreads fail
        }
    }

    threadpool = returnMe;
}

// DONE-ISH, UNTESTED
void work_stack_wait() {
    while(workstack->head != NULL || workstack->numExecuting > 0) {
        // loop until head is empty and numExecuting is 0
    }
    return;
}

// destroys and frees threadpool and workstack DONE-ISH, UNTESTED
void thread_pool_destroy() {
    work_stack_wait();

    //create the destroy task to kill all worker thread
    Task destroy;
    destroy.pnum = -1;

    //send special DESTROY task
    for(int i = 0; i < threadpool->numWorkerThreads; i++) {
      // printf("destroy %d\n",i);
      work_stack_submit(&destroy);
      // threadpool->numWorkerThreads--;
    }

    //wait for all threads to return
    for(int i = 0; i < threadpool->numWorkerThreads; i++) {
        if(pthread_join(threadpool->workerArr[i], NULL) != 0) {
            perror("pthread_join");
        }
    }

    free(threadpool->workerArr);
}


// Working with metrics...
// Recording the current time in a `struct timespec`:
//    clock_gettime(CLOCK_MONOTONIC, &metric->created);
// Getting the elapsed time in microseconds between two timespecs:
//    duration = TIME_DIFF_MICROS(metric->created, metric->scheduled);
// Use `print_formatted_metric(...)` to write a metric to the logfile. 
void print_formatted_metric(TaskMetric* metric, FILE* fp) {
  fprintf(fp, "RDD %p Part %d Trans %d -- creation %10jd.%06ld, scheduled %10jd.%06ld, execution (usec) %ld\n",
	  metric->rdd, metric->pnum, metric->rdd->trans,
	  metric->created.tv_sec, metric->created.tv_nsec / 1000,
	  metric->scheduled.tv_sec, metric->scheduled.tv_nsec / 1000,
	  metric->duration);
}

int max(int a, int b)
{
  return a > b ? a : b;
}

RDD *create_rdd(int numdeps, Transform t, void *fn, ...)
{
  RDD *rdd = malloc(sizeof(RDD));
  if (rdd == NULL)
  {
    printf("error mallocing new rdd\n");
    exit(1);
  }

  rdd->numpartitions = 0; // ADDED this
  va_list args;
  va_start(args, fn);

  int maxpartitions = 0;
  for (int i = 0; i < numdeps; i++)
  {
    RDD *dep = va_arg(args, RDD *);
    rdd->dependencies[i] = dep;
    rdd->numpartitions = dep->numpartitions; // ADDED THIS FOR OVERHEAD
    maxpartitions = max(maxpartitions, dep->partitions->size);
  }
  va_end(args);

  rdd->numdependencies = numdeps;
  rdd->trans = t;
  rdd->fn = fn;
  rdd->partitions = list_initalize(rdd->numpartitions); // ADDED this
  return rdd;
}

/* RDD constructors */
RDD *map(RDD *dep, Mapper fn)
{
  return create_rdd(1, MAP, fn, dep);
}

RDD *filter(RDD *dep, Filter fn, void *ctx)
{
  RDD *rdd = create_rdd(1, FILTER, fn, dep);
  rdd->ctx = ctx;
  return rdd;
}

RDD *partitionBy(RDD *dep, Partitioner fn, int numpartitions, void *ctx)
{
  RDD *rdd = create_rdd(1, PARTITIONBY, fn, dep);
  rdd->partitions = list_initalize(numpartitions);
  rdd->numpartitions = numpartitions;
  rdd->ctx = ctx;
  return rdd;
}

RDD *join(RDD *dep1, RDD *dep2, Joiner fn, void *ctx)
{
  RDD *rdd = create_rdd(2, JOIN, fn, dep1, dep2);
  rdd->ctx = ctx;
  return rdd;
}

/* A special mapper */
void *identity(void *arg)
{
  return arg;
}

/* Special RDD constructor.
 * By convention, this is how we read from input files. */
RDD *RDDFromFiles(char **filenames, int numfiles)
{
  RDD *rdd = malloc(sizeof(RDD));
  rdd->partitions = list_initalize(numfiles);

  for (int i = 0; i < numfiles; i++)
  {
    FILE *fp = fopen(filenames[i], "r");
    if (fp == NULL) {
      perror("fopen");
      exit(1);
    }
    //list_add_element(rdd->partitions, fp);
    rdd->partitions->array[i] = fp; // changed to work with arrays
  }

  rdd->numdependencies = 0;
  rdd->numpartitions = numfiles; // added this
  rdd->trans = FILE_BACKED; // changed this from MAP to FILE_BACKED
  rdd->fn = (void *)identity;
  return rdd;
}

// ADDED CODE

// Materializes all of the RDDs in the DAG, UNTESTED
void execute(RDD* rdd) {
  Task *task;
  
  // execute the other dependencies first
  for(int i = 0; i < rdd->numdependencies; i++) {
    execute(rdd->dependencies[i]);
  }

  //wait for all threads to finish
  work_stack_wait();

  for(int i = 0; i < rdd->numpartitions; i++) {
    task = create_task(rdd, i); // create a new task for each partition
    work_stack_submit(task);
  }
  //return;
}

// Initializes the workstack and Theadpool, TODO the intialize TaskMetrics, UNTESTED
void MS_Run() {
  // get number of cores
  cpu_set_t set;
  CPU_ZERO(&set);

  if(sched_getaffinity(0, sizeof(set), &set) == -1) {
    perror("sched_getaffinity");
    exit(1);
  }

  // initialize the thread pool and work stack
  work_stack_init();
  thread_pool_init(CPU_COUNT(&set));
  metricpool_init();
  //metricworker_init();
}

// TODO tear down the TaskMetrics, UNTESTED
void MS_TearDown() {
  metric_destroy();
  thread_pool_destroy();
}

// counts the number of lines in RDD, UNTESTED
int count(RDD *rdd) {
  execute(rdd);

  work_stack_wait();

  // print all the items in rdd
  // aka... `p(item)` for all items in rdd
  struct List* myPart = rdd->partitions;
  struct List* innerList;
  int count = 0;

  for(int i = 0; i < myPart->size; i++) {

    innerList = (List*)myPart->array[i];

    if(innerList == NULL) {
      printf("innerList is NULL");
    }
    else{
      //idk if this is needed
      for(int j = 0; j < innerList->size; j++) {
        count++;
      }
    }
  }

  return count;
}

// prints all lines in RDD, UNTESTED
void print(RDD *rdd, Printer p) {
  execute(rdd);

  work_stack_wait();

  // print all the items in rdd
  // aka... `p(item)` for all items in rdd
  struct List* myPart = rdd->partitions;
  struct List* innerList;

  for(int i = 0; i < myPart->size; i++) {

    innerList = (List*)myPart->array[i];

    //idk if this is needed
    for(int j = 0; j < innerList->size; j++) {
      p(innerList->array[j]);
    }
  }
}
